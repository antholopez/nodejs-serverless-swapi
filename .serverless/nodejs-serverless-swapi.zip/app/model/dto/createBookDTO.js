"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateBookDTO = void 0;
class CreateBookDTO {
}
exports.CreateBookDTO = CreateBookDTO;
//# sourceMappingURL=createBookDTO.js.map