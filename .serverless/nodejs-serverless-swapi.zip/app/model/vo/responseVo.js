"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResponseVO = exports.ResponseBodyVO = void 0;
class ResponseBodyVO {
}
exports.ResponseBodyVO = ResponseBodyVO;
class ResponseVO {
}
exports.ResponseVO = ResponseVO;
//# sourceMappingURL=responseVo.js.map